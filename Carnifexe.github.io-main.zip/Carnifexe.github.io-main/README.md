# Grand DE01 SAHP Bußgeldrechner

Grundidee von Joshi Enrage/devgosling. Von Maik Bosa x Moritz Yane überarbeitet.

[Lizenzvereinbarung](https://github.com/Carnifexe/Carnifexe.github.io/blob/main/bussgeldrechner/LICENSE)
